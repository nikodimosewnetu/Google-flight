import React, { useState } from 'react';
import { useFlightContext } from '../contexts/FlightContext';
import { searchFlights } from '../api';
import { Form, Button, Container, Row, Col, Table } from 'react-bootstrap';

const FlightSearch = () => {
  const { searchParams, setSearchParams, flights, setFlights, loading, setLoading, error, setError } = useFlightContext();
  const [searching, setSearching] = useState(false);

  const handleChange = (e) => {
    setSearchParams({ ...searchParams, [e.target.name]: e.target.value });
  };
  const handleSearch = async () => {
    setLoading(true);
    setSearching(true);
    setError(null);
    const params = {
      originSkyId: searchParams.origin,
      destinationSkyId: searchParams.destination,
      originEntityId: '27544008',
      destinationEntityId: '27537542',
      date: searchParams.departureDate,
      returnDate: searchParams.returnDate,
      cabinClass: searchParams.cabinClass,
      adults: searchParams.adults,
      currency: 'USD',
      market: 'en-US',
      countryCode: 'US',
    };
  
    try {
      const data = await searchFlights(params);
      
      // Make sure to check the structure of the response before setting it
      if (Array.isArray(data.data)) {
        setFlights(data.data); 
        console.log(flights);// Set the flight data if it's an array
      } else {
        setError('No flights found or incorrect data format.');
      }
    } catch (error) {
      setError('Error fetching flights.');
    }
    
    setLoading(false);
    setSearching(false);
  };
  

  return (
    <Container>
      <Row className="my-4">
        <Col md={6}>
          <Form>
            <Form.Group controlId="origin">
              <Form.Label>Origin</Form.Label>
              <Form.Control type="text" name="origin" value={searchParams.origin} onChange={handleChange} />
            </Form.Group>
            <Form.Group controlId="destination">
              <Form.Label>Destination</Form.Label>
              <Form.Control type="text" name="destination" value={searchParams.destination} onChange={handleChange} />
            </Form.Group>
            <Form.Group controlId="departureDate">
              <Form.Label>Departure Date</Form.Label>
              <Form.Control type="date" name="departureDate" value={searchParams.departureDate} onChange={handleChange} />
            </Form.Group>
            <Form.Group controlId="returnDate">
              <Form.Label>Return Date</Form.Label>
              <Form.Control type="date" name="returnDate" value={searchParams.returnDate} onChange={handleChange} />
            </Form.Group>
            <Form.Group controlId="cabinClass">
              <Form.Label>Cabin Class</Form.Label>
              <Form.Control as="select" name="cabinClass" value={searchParams.cabinClass} onChange={handleChange}>
                <option value="economy">Economy</option>
                <option value="premium_economy">Premium Economy</option>
                <option value="business">Business</option>
                <option value="first">First</option>
              </Form.Control>
            </Form.Group>
            <Form.Group controlId="adults">
              <Form.Label>Adults</Form.Label>
              <Form.Control type="number" name="adults" value={searchParams.adults} onChange={handleChange} />
            </Form.Group>
            <Button variant="primary" onClick={handleSearch} disabled={searching}>
              {searching ? 'Searching...' : 'Search Flights'}
            </Button>
          </Form>
        </Col>
      </Row>

      {/* Display results */}
      <Row>
        <Col>
          <Table striped bordered hover responsive>
            <thead>
              <tr>
                <th>Airline</th>
                <th>Price</th>
                <th>Departure</th>
                <th>Arrival</th>
              </tr>
            </thead>
            <tbody>
  {searching ? (
    <tr><td colSpan="4">Loading...</td></tr>
  ) : (
    Array.isArray(flights) && flights.length > 0 ? (
      flights.map((flight, index) => (
        <tr key={index}>
          <td>{flight.airline}</td>
          <td>{flight.price} USD</td>
          <td>{new Date(flight.departureTime).toLocaleString()}</td>
          <td>{new Date(flight.arrivalTime).toLocaleString()}</td>
        </tr>
      ))
    ) : (
      <tr><td colSpan="4">No flights found</td></tr>
    )
  )}
</tbody>

          </Table>
        </Col>
      </Row>
    </Container>
  );
};

export default FlightSearch;
