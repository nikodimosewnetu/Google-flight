import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const api = axios.create({
  baseURL: 'https://sky-scrapper.p.rapidapi.com/api/v2/flights/',
  headers: {
    'x-rapidapi-host': 'sky-scrapper.p.rapidapi.com',
    'x-rapidapi-key': '18becb2f2bmsh2a6d16062fbbda0p1df5f6jsna68e5294a9fa' // Use your API key
  }
});

export const searchFlights = async (params) => {
  try {
    const response = await api.get('searchFlights', { params });
    return response.data;
  } catch (error) {
    console.error('Error fetching flights:', error);
    throw error;
  }
};
